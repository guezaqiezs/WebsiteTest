<?php
/* Copyright (C) 2011 SEBLOD. All Rights Reserved. */

// No Direct Access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<fieldset class="adminform">
<legend class="legend-border"><?php echo JText::_( 'ITEM TYPE' ); ?></legend>
	<table class="admintable">
		<tr>
			<td>
				<?php echo '<i>' . JText::_( 'NO ITEM TYPE' ) . '</i>'; ?>
			</td>
		</tr>
	</table>
</fieldset>