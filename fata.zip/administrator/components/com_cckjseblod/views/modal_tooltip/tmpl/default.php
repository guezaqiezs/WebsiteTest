<?php
/* Copyright (C) 2011 SEBLOD. All Rights Reserved. */

// No Direct Access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<div>	
	<div id="ajaxTool-title">
		<strong><?php echo $this->legend; ?></strong>
	</div>
	<div id="ajaxTool-text">
		<?php echo htmlspecialchars_decode($this->tooltip); ?>
	</div>
</div>
		
<div class="clr"></div>