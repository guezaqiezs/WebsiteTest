<?php
/* Copyright (C) 2011 SEBLOD. All Rights Reserved. */

// No Direct Access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<div class="submenu-box">
	<div class="submenu-pad">
		<ul id="submenu" class="configuration">
			<li><a id="process-cck" class="active"><?php echo JText::_( 'PROCESS CONFIG CCK' ); ?></a></li>
  			<li><a id="process-site"><?php echo JText::_( 'PROCESS CONFIG SITE' ); ?></a></li>
   			<li><a id="process-cek"><?php echo JText::_( 'COMPONENT' ); ?></a></li>
   			<!--<li><a id="help"><?php /*echo JText::_( 'PRODUCT HELP' );*/ ?></a></li>-->
   			<!--<li><a id="update"><?php /*echo JText::_( 'PRODUCT UPDATE' );*/ ?></a></li>-->
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="clr"></div>