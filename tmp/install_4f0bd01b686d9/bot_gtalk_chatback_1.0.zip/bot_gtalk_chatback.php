<?php
/**
* @version $Id: 1.00 2008-01-09 02:31:11Z 
* @package Joomla
* @copyright Copyright (C) 2008 ZarateProp. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

$_MAMBOTS->registerFunction( 'onPrepareContent', 'botGtalkChatback' );

function botGtalkChatback ($published, &$row, &$params, $page=0 ) {
	global $Itemid, $task, $database, $gtalkChatbackUrl;
    
	$query = "SELECT id FROM #__mambots WHERE element = 'bot_gtalk_chatback' AND folder = 'content'";
    $database->setQuery( $query );
    $id = $database->loadResult();
    $mambot = new mosMambot( $database );
    $mambot->load( $id );
	$param =& new mosParameters( $mambot->params );
	$url 	= trim ($param->get('url', ''));
	$tk 	= trim ($param->get('tk', ''));
	$width 	= trim ($param->get('width', ''));
	$height	= trim ($param->get('height', ''));
	$allowTransparency = intval ($param->get('allowTransparency', 1));
	$frameBorder = intval ($param->get('frameBorder', 1));
	
	$gtalkChatbackUrl = '<IFRAME src="' . $url . '?tk=' . $tk . '&amp;w=' . $width . '&amp;h=' . $height . '" frameBorder=' . $frameBorder . ' width=' . $width . ' height=' . $height . ($allowTransparency ? " allowTransparency" : "") .  '></IFRAME>';
	
    // define the regular expression for the bot
	$regex = "#{botGtalkChatback*(.*?)}#s";

	// see if mombot is not published
	if (!$published) {
		$row->text = preg_replace( $regex, '', $row->text );
		return;
	}
	
	// perform the replacement
	$row->text = preg_replace_callback( $regex, 'botGtalkChatback_replacer', $row->text );

	return true;
}

function botGtalkChatback_replacer( &$matches ) {	
	# Bot Parameters loading
	global $gtalkChatbackUrl;
   
 return $gtalkChatbackUrl;
}
?>